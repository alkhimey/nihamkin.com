//    muRata Optical Sensor (PS&ALS) Starter Kit          
//    Last updated : 25-Nov.2015               
//
//    Optical sensor has built-in ASIC with I2C interface and
//    we can obtain Proximity(PROX) values to judge whether there's adjacent object
//    and obtain AmbientLight(ALS) values to calculate ambient light intensity [lux].
//
//    In this sample code, we initialize device and start measurement
//    in setup() by writing configuration values to registers.
//    Once device's data is ready, INT pin falls to LOW.
//    It is detected by Arduino as an external interruption, 
//    and IRQ handler sets a flag which is regularly monitored in main().
//
//    In the main loop, once flag is set,
//    we specify interruption source by reading INTERRUPTION register
//    and read data from device and process it accordingly.
//
//    In this sample code, PROX and ALS is obtained in every 200ms
//    and the result is shown in serial window. 
//    You can observe 
//        Proximity : 0 <-- when there is no adjacent object
//        Proximity : 1 <-- when there is an adjacent object
//        Ambient Light : xxx [lux] <-- value varies depends on environment.
//        (low value when covered, high value when exposed to light)
//    
//    For entire operation flow, configuration, data handling,
//    please refer to LT-1PA01_Application_Note.pdf
//                                          
//     ______Pin Layout of starter kit______  
//    |                                     | 
//    |  (3.3V)                             | 
//    |____VCC___SCL____SDA___INT____GND____| 
//                                          
//    Pin connection                                         
//    Starter Kit       arduino UNO board
//    SCL         <-->  A5
//    SDA         <-->  A4
//    INT         <-->  D2

#include <Wire.h>

#define REG_CHIPID      0x00
#define REG_CONFIGURE0  0x01
#define REG_CONFIGURE1  0x02
#define REG_CONFIGURE2  0x03
#define REG_INTERRUPT   0x04
#define REG_PROX_TH1    0x05
#define REG_PROX_TH2    0x06
#define REG_ALS_TH1     0x07
#define REG_ALS_TH2     0x08
#define REG_ALS_TH3     0x09
#define REG_PROX_DT     0x0A
#define REG_ALS_DT1     0x0B
#define REG_ALS_DT2     0x0C
#define REG_PROX_WASH   0x0D


void init_device();
void callibrate_optical_sensor() ;
void write_to_register(byte, byte);
byte read_from_register(byte);
void start_measurement();
float GetLightValue();


boolean prox_status = false;

const float OPTICAL_THRESHOLD = 130;

const int SWIPE_INTERVAL_LENGTH = 120;
const int HOLD_INTERVAL_LENGTH = 1300;

const int SWIPE_CHOICE = 1;
const int HOLD_CHOICE = 2;

const float INVALID_SENSOR_VALUE = 1.0;
float max_val = 0;
float min_val = 4000;

void setup_optic() {

  // Initialize OPT sensor
  Wire.begin();
  //Serial.print("Device ID = 0b");                       // Just for Test.
  //Serial.println(read_from_register(REG_CHIPID), BIN);  // Just for Test.
  init_device();

  // Start Measurement
  start_measurement();
  callibrate_optical_sensor();
  //start_mili = millis();
}

int get_user_input() {
  int user_choice = 0;
  bool user_interaction_finished = false;
  unsigned long start_mili = millis();
  unsigned long prev_millis = millis();
  bool x = false; 

  turnOffLights();       

  while (!user_interaction_finished) {

    if(abs(millis() - prev_millis) > 600) {
      prev_millis = millis();
      if (x == true) {
        turnOnLights(strip.Color(0, 0, 255));
      } else {
        turnOffLights();       
      }
      x= !x;
    }
    
    float light_value = GetLightValue();
    if (light_value > INVALID_SENSOR_VALUE) {
      
      
      if(light_value <  (min_val - OPTICAL_THRESHOLD)){  
        if ((millis() - start_mili) > SWIPE_INTERVAL_LENGTH) {
          user_choice = SWIPE_CHOICE;
        } 
        if ((millis() - start_mili) > HOLD_INTERVAL_LENGTH) {
          user_choice = HOLD_CHOICE;
          break;
        }
         
      }
      else {
        start_mili = millis();
        if (user_choice != 0) {
         user_interaction_finished = true;
        }
      }
    }
  }

  return user_choice;
  
}

int clear_interrupt(){
  byte int_source = read_from_register(REG_INTERRUPT);

/*
  // Brownout detection
  if((int_source & 0x10) != 0x00){   
    Serial.println("INT : BROWNOUT");
  }
*/

  // PROX flag
  if((int_source & 0x80) != 0x00){
    //Serial.println("INT : PROX");
    //clear flag
    write_to_register(REG_INTERRUPT, ((int_source | 0x18) ^ 0x80));
  }

  // ALS flag
  if((int_source & 0x08) != 0x00){
    //Serial.println("INT : ALS"); 
    //clear flag
    write_to_register(REG_INTERRUPT, ((int_source | 0x90) ^ 0x08));
  }
  
  return int_source;
}

void start_measurement(){
  //Serial.println("start measurement.");
  
  // Start Measurement
  write_to_register(REG_CONFIGURE0, 0x24);  // Set PROX start bit
  write_to_register(REG_CONFIGURE1, 0x87);  // Set ALS start bit
}

void init_device(){
  // Brownout Check, Interrupt Setting
  write_to_register(REG_INTERRUPT,  0x00);
  
  // Interrupt Setting
  write_to_register(REG_PROX_TH1,   0xFF);
  write_to_register(REG_PROX_TH2,   0x00);  
  write_to_register(REG_ALS_TH1,    0xFF);
  write_to_register(REG_ALS_TH2,    0xF0);
  write_to_register(REG_ALS_TH3,    0x00);

  // Interrupt Setting, PROX back-scatter setting, ALS sensitivity range setting
  write_to_register(REG_CONFIGURE1, 0x83);

  // PROX sleeping time setting
  write_to_register(REG_CONFIGURE0, 0x04);
 
  // ALS IR compensation setting
  write_to_register(REG_CONFIGURE2, 0x10);
}


/*************** I2C basic functions ******************/
byte read_from_register(byte address){
  Wire.beginTransmission(0x44);
  Wire.write(address);          // register address
  Wire.endTransmission();
  Wire.requestFrom(0x44, 1);    // request 1 byte from slave 0x44
  byte res[1];
  int i = 0;
  while(Wire.available()){
    res[i] = Wire.read();   // receive a byte as character
    i++;
  }
  return res[0];
}

void write_to_register(byte address, byte value){
  Wire.beginTransmission(0x44); // device address
  Wire.write(address);          // register address
  Wire.write(value);            // value to be set
  Wire.endTransmission();
}

float GetLightValue() {
    // Clear Interrupt Source Flags
    byte int_source = clear_interrupt();

    // PROX
    if((int_source & 0x80) != 0x00){
      // read measurement data
      byte prox_data = read_from_register(REG_PROX_DT);
      byte prox_wash = read_from_register(REG_PROX_WASH);
      
      if((prox_wash & 0x01) != 0x00){ 
        // Ambient Light is satulated --> no adjacent object
        prox_status = false;
      }else{
        // Ambient Light is NOT satulated
        int threshold_upper = 80;
        int threshold_lower = 40;
        if(prox_status == false){
          if(prox_data > threshold_upper){
            prox_status = true;
          }
        }else{
          if(prox_data < threshold_lower){
            prox_status = false;
          }
        }        
      }
      //Serial.print("Proximity \t: ");
      //Serial.println(prox_status);
    }

    // ALS
    if((int_source & 0x08) != 0x00){
      // read measurement data
      byte als_data[2];
      als_data[0] = read_from_register(REG_ALS_DT1);  // Higher Byte
      als_data[1] = read_from_register(REG_ALS_DT2);  // Lower Byte
      int als_dt = (als_data[0]<<8) + als_data[1];

      // calculation
      float lux = (float)als_dt * 0.977;
      //Serial.print("Ambient Light \t: ");
      //Serial.print(lux);
      //Serial.println(" [lux]");

      //return prox_status;
      return lux;
    }

    return INVALID_SENSOR_VALUE;
}

void callibrate_optical_sensor() {
  Serial.println("Callibration!! Zhito please don't interrupt :)");
  while (millis() < 500) {
    int val = GetLightValue();
    if (val > 1.0) {
      max_val = max(max_val, val);
      min_val = min(min_val, val);
    }
  }

  Serial.print("Max: ");
  Serial.print(max_val);
  Serial.print(" Min: ");
  Serial.println(min_val);
}

