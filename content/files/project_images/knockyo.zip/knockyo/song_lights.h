#include <Adafruit_NeoPixel.h>
#ifdef __AVR__
  #include <avr/power.h>
#endif

#define PIXEL_PIN 6

const int buzzerPin = 9;

void init_song_lights();
int frequency(char note);
void play_intro_song();

void turnOnLights(uint32_t c);
void turnOffLights();
void colorWipe(uint32_t c, uint8_t wait);
void displayScore(unsigned int x, unsigned int y);

// Parameter 1 = number of pixels in strip
// Parameter 2 = Arduino pin number (most are valid)
// Parameter 3 = pixel type flags, add together as needed:
//   NEO_KHZ800  800 KHz bitstream (most NeoPixel products w/WS2812 LEDs)
//   NEO_KHZ400  400 KHz (classic 'v1' (not v2) FLORA pixels, WS2811 drivers)
//   NEO_GRB     Pixels are wired for GRB bitstream (most NeoPixel products)
//   NEO_RGB     Pixels are wired for RGB bitstream (v1 FLORA pixels, not v2)
Adafruit_NeoPixel strip = Adafruit_NeoPixel(60, PIXEL_PIN, NEO_GRB + NEO_KHZ800);

void init_song_lights()
{
  pinMode(buzzerPin, OUTPUT);

  strip.begin();
  strip.show(); // Initialize all pixels to 'off'
}

// How to set up using this Header file:
/*
void setup() {
  // put your setup code here, to run once:
  init_song_lights();

// "Ground" for pixels, since we ran out of ground pins and are lazy
    pinMode(4, OUTPUT);
    digitalWrite(4,LOW);
}
*/

/* // Example usage:
void loop() {

play_intro_song(); // song + lights

// flash

turnOnLights(strip.Color(0, 0, 255));
delay(2000);
turnOffLights();
delay(2000);


// circle

colorWipe( strip.Color(0, 0, 255), 50);
delay(2000);



// score
for (unsigned int i = 0; i <= 1000; i+=100)
{
  displayScore(i,1000);
  delay(1000);
  turnOffLights();
  delay(1000);
}

} // loop
*/


void turnOnLights(uint32_t c) {
  for(uint16_t i=0; i<16; i++) {
    strip.setPixelColor(i, c);
  }
    strip.show();
}

void turnOffLights() {
  for(uint16_t i=0; i<16; i++) {
    strip.setPixelColor(i, 0);
  }
    strip.show();
}

void colorWipe(uint32_t c, uint8_t wait)
{
  for(uint16_t i=0; i<16; i++) {
    strip.setPixelColor(i,c);
    strip.show();
    delay(wait);
 }
   turnOffLights();
}


void displayScore(unsigned int x, unsigned int y)
{
  unsigned int num_pixels = (unsigned int) (16 * (float) ((float) x/ (float) y)) ;
  uint32_t colour;

  if (num_pixels >= 14)
   colour = strip.Color(0, 0, 255); // blue
  else if (num_pixels >= 10)
   colour = strip.Color(0, 255, 0); // green
  else if (num_pixels >= 5)
   colour = strip.Color(255, 255, 0); // yellow
  else
   colour = strip.Color(255, 0, 0); // red

  for(uint16_t i=0; i<num_pixels; i++) {
     strip.setPixelColor(i, colour);
     strip.show();
     delay(100);
  }

}


// Input a value 0 to 255 to get a color value.
// The colours are a transition r - g - b - back to r.
uint32_t Wheel(byte WheelPos) {
  WheelPos = 255 - WheelPos;
  if(WheelPos < 85) {
    return strip.Color(255 - WheelPos * 3, 0, WheelPos * 3);
  }
  if(WheelPos < 170) {
    WheelPos -= 85;
    return strip.Color(0, WheelPos * 3, 255 - WheelPos * 3);
  }
  WheelPos -= 170;
  return strip.Color(WheelPos * 3, 255 - WheelPos * 3, 0);
}


const int songLength = 67;
char notes[] = "aaaa agec caagfg fbbbagf faagfa aCD DCaf CDEFEDC aCD DDCaf fgaagfa";
int beats[] = {1,1,1,2,1,1,2,1,2,1,1,2,2,1,2,2,4,1,1,2,1,2,1,2,2,1,1,2,2,1,2,3,1,1,3,3,2,2,1,2,3,1,1,1,1,3,2,2,3,1,1,3,2,3,1,1,2,2,3,1,1,3,1,2,1,4};

// The tempo is how fast to play the song.
// To make the song play faster, decrease this value.

int tempo = 200;

void play_intro_song() 
{
  int i, duration;
  int colour = 0;
  int pixel = 0;

  for (i = 0; i < songLength; i++) // step through the song arrays
  {

   
      for (int k=0; k < 16; k=k+3) {
        strip.setPixelColor(k+pixel, Wheel( (k+colour) % 255));    //turn every third pixel on
      }
      strip.show();
      colour+=5;

    
    duration = beats[i] * tempo;  // length of note/rest in ms

    if (notes[i] == ' ')          // is this a rest? 
    {
      delay(duration);            // then pause for a moment
    }
    else                          // otherwise, play the note
    {
      tone(buzzerPin, frequency(notes[i]), duration);
      delay(duration);            // wait for tone to finish
    }

     for (int k=0; k < 16; k=k+3) {
        strip.setPixelColor(k+pixel, 0);        //turn every third pixel off
      }
     pixel++; pixel %=3;

    delay(tempo/10);              // brief pause between notes
  }

}


int frequency(char note) 
{
  // This function takes a note character (a-g), and returns the
  // corresponding frequency in Hz for the tone() function.

  int i;
  const int numNotes = 11;  // number of notes we're storing

  // The following arrays hold the note characters and their
  // corresponding frequencies. The last "C" note is uppercase
  // to separate it from the first lowercase "c". If you want to
  // add more notes, you'll need to use unique characters.

  // For the "char" (character) type, we put single characters
  // in single quotes.

  char names[] = { 'c', 'd', 'e', 'f', 'g', 'a', 'b', 'C', 'D', 'E', 'F' }; // b is flat, 466 (real b is 494)
  int frequencies[] = {262, 294, 330, 349, 392, 440, 466, 523, 587, 659, 699}; // http://peabody.sapp.org/class/st2/lab/notehz/

  // Now we'll search through the letters in the array, and if
  // we find it, we'll return the frequency for that note.

  for (i = 0; i < numNotes; i++)  // Step through the notes
  {
    if (names[i] == note)         // Is this the one?
    {
      return(frequencies[i]);     // Yes! Return the frequency
    }
  }
  return(0);  // We looked through everything and didn't find it,
              // but we still need to return a value, so return 0.
}
